/*
$ Nome: Pedro Lucas Medina Pereira
        Darla Garcia
$ Engenharia de computação - IFTM
$ POOV
 */
package darla_pedro_trabalho1_ex1;

/**
 *
 * @author darla
 */
public class Pessoa {
    String ra, nome, curso, area;
    int idade;
    
    
}
