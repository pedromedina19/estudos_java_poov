/*
$ Nome: Pedro Lucas Medina Pereira
        Darla Garcia
$ Engenharia de computação - IFTM
$ POOV
 */
package darla_pedro_trabalho1_ex2;

public class conta_bancaria {
    String numr, senha, proprietario;
    double saldo, limite;
    
}
