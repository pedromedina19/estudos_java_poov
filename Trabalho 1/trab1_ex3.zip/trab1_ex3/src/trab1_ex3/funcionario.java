/*
$ Nome: Pedro Lucas Medina Pereira
        Darla Garcia 
$ Engenharia de computação - IFTM
$ POOV
 */
package trab1_ex3;

public class funcionario {
    String CPF, nome, funcao;
    float salario;
}
